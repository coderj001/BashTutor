#!/bin/bash

tar -czf /home /tmp/linux.conf
