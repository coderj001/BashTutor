#!/bin/bash

# This script demostrates I/O redirections.
FILE="/tmp/data"
head -n1 /etc/passwd > ${FILE}
