#!/bin/bash

read -p "Username: " username
read -sp "Password: " password

echo ""
echo $username
echo $password
